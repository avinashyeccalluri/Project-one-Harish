<header>
            <div class="info" style="display:none">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <!--<div class="col">Working Hours Monday - Friday <span class="id-color"><strong>08:00-16:00</strong></span></div>
                            <div class="col">Toll Free <span class="id-color"><strong>1800.899.900</strong></span></div>-->
                            <!-- social icons -->
                            <div class="col social">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                                <!--<a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-rss"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a>
                                <a href="#"><i class="fa fa-envelope-o"></i></a>-->
                            </div>
                            <!-- social icons close -->
                        </div>
                    </div>
                </div>
            </div>

            <div class="container" style="width:100%">
                <div class="row">
                    <div class="col-md-12">
                        <!-- logo begin -->
                        <div id="logo">
                            <a href="index.php">
                                <img class="logo" src="images/logo.png" alt="">
                            </a>
                        </div>
                        <!-- logo close -->

                        <!-- small button begin -->
                        <span id="menu-btn"></span>
                        <!-- small button close -->

                        <!-- mainmenu begin -->
                        <nav>
                            <ul id="mainmenu">
								<li><a href="index.php">Home<span></span></a></li>
                                <li><a href="about_us.php">About Us<span></span></a></li>
                                <li><a href="our_projects.php">Our Projects</a></li>
                                <li><a href="services.php">Services</a>
                                    <ul>
                                        <li><a href="construction.php">Construction</a></li>
                                        <li><a href="architectural_design.php">Architectural Design</a></li>
                                        <li><a href="interior_design.php">Interior Design</a></li>
                                        
                                    </ul>
                                </li>
                                <li><a href="career.php">Career</a></li>
                                <li><a href="contact.php">Contact</a></li>
                            </ul>
                        </nav>
                        

                    </div>
                    <!-- mainmenu close -->

                </div>
            </div>
        </header>