<footer>
                <div class="container">
                    <div class="row">
                        <div class="col-md-7">
                            <img src="images/logo.png" class="logo-small" alt=""><br>
                           ARTEG associates is a Chennai -based Architectural firm founded in 2016. With our clients as our partners, We are a team of dedicated professionals from versatile backgrounds to serve innovative and ingenious design solutions. We are a multi-dimensional design firm for Architecture, Interior design, Renovation, and Product design. We create transformative solutions in all scales and in all sectors in synchronicity with the surroundings.


                        </div>

                        

                  
						
						  <div class="col-md-5">
                            <h3>Contact Us</h3>
                            <div class="widget widget-address">
                                <address>
                                    <span>No.25a, 1st floor, 1st main road, Anna Nagar West, near park avenue hotel, Allapuram, Vellore</span>
                                    <span><strong>Phone: </strong>097904 40581</span>
                                    <!--<span><strong>Fax:</strong>(208) 333 9298</span>-->
                                    <span><strong>Email:</strong><a href="mailto:info@arteg.in">info@arteg.in</a></span>
                                    <span><strong>Web:</strong><a href="#">http://www.arteg.in</a></span>
                                </address>
                            </div>
                        </div>
						
						
                    </div>
                </div>

                <div class="subfooter">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">
                                &copy; Copyright 2020 - ARTEG Architects & Associates  by <span class="id-color">TEJUS</span>
                            </div>
                            <div class="col-md-6 text-right">
                                <div class="social-icons">
                                    <a href="#"><i class="fa fa-facebook fa-lg"></i></a>
                                    <a href="#"><i class="fa fa-instagram fa-lg"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="#" id="back-to-top"></a>
            </footer>